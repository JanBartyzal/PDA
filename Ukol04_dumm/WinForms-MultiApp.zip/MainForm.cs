
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace MultiApp
{
    public class Predmet
    {
        public string Zkratka { get; }
        public string Nazev { get; }

        public Predmet(string zkratka, string nazev)
        {
            Zkratka = zkratka;
            Nazev = nazev;
        }

        public override string ToString()
        {
            return $"{Zkratka} - {Nazev}";
        }
    }

    public partial class MainForm : Form
    {
        private List<Predmet> predmety = new List<Predmet>();
        private ListBox predmetListBox;
        private TextBox selectedSubjects;

        public MainForm()
        {
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            // Výběr předmětu pomocí RadioButton
            GroupBox radioGroup = new GroupBox() { Text = "Výběr předmětu (RadioButton)", Width = 300, Height = 150, Top = 850, Left = 20 };
            RadioButton rb1 = new RadioButton() { Text = "Matematika", Top = 20, Left = 10 };
            RadioButton rb2 = new RadioButton() { Text = "Fyzika", Top = 45, Left = 10 };
            RadioButton rb3 = new RadioButton() { Text = "Programování", Top = 70, Left = 10 };
            TextBox selectedSubjectRadio = new TextBox() { Top = 100, Left = 10, Width = 200, ReadOnly = true };
            rb1.CheckedChanged += (s, e) => { if (rb1.Checked) selectedSubjectRadio.Text = rb1.Text; };
            rb2.CheckedChanged += (s, e) => { if (rb2.Checked) selectedSubjectRadio.Text = rb2.Text; };
            rb3.CheckedChanged += (s, e) => { if (rb3.Checked) selectedSubjectRadio.Text = rb3.Text; };
            radioGroup.Controls.Add(rb1);
            radioGroup.Controls.Add(rb2);
            radioGroup.Controls.Add(rb3);
            radioGroup.Controls.Add(selectedSubjectRadio);

            // Výběr předmětu pomocí ComboBox
            GroupBox comboGroup = new GroupBox() { Text = "Výběr předmětu (ComboBox)", Width = 300, Height = 100, Top = 1020, Left = 20 };
            ComboBox subjectCombo = new ComboBox() { Top = 20, Left = 10, Width = 200 };
            subjectCombo.Items.AddRange(new object[] { "Matematika", "Fyzika", "Programování" });
            TextBox selectedSubjectCombo = new TextBox() { Top = 50, Left = 10, Width = 200, ReadOnly = true };
            subjectCombo.SelectedIndexChanged += (s, e) => selectedSubjectCombo.Text = subjectCombo.SelectedItem.ToString();
            comboGroup.Controls.Add(subjectCombo);
            comboGroup.Controls.Add(selectedSubjectCombo);

            // Přidání do formuláře
            Controls.Add(radioGroup);
            Controls.Add(comboGroup);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
