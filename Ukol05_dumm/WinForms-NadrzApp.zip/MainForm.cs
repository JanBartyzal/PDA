
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace NadrzApp
{
    public class Nadrz
    {
        public string Identifikator { get; }
        private int stav;
        public int Objem { get; }

        public Nadrz(string identifikator, int objem)
        {
            Identifikator = identifikator.ToLower();
            Objem = objem;
            stav = 0;
        }

        public void Pridat(int mnozstvi)
        {
            if (mnozstvi < 0 || stav + mnozstvi > Objem)
                throw new ArgumentException("Nelze přidat: překročení kapacity.");
            stav += mnozstvi;
        }

        public void Odebrat(int mnozstvi)
        {
            if (mnozstvi < 0 || stav - mnozstvi < 0)
                throw new ArgumentException("Nelze odebrat: nedostatek v nádrži.");
            stav -= mnozstvi;
        }

        public int Stav => stav;

        public override string ToString()
        {
            return $"{Identifikator} : {stav}/{Objem}";
        }
    }

    public class SeznamNadrzi
    {
        private List<Nadrz> nadrze = new List<Nadrz>();

        public void PridatNadrz(string identifikator, int objem)
        {
            if (nadrze.Any(n => n.Identifikator == identifikator.ToLower()))
                throw new ArgumentException("Nádrž s tímto identifikátorem již existuje.");
            nadrze.Add(new Nadrz(identifikator, objem));
        }

        public void OdebratNadrz(string identifikator)
        {
            var nad = nadrze.FirstOrDefault(n => n.Identifikator == identifikator.ToLower());
            if (nad == null)
                throw new ArgumentException("Nádrž neexistuje.");
            if (nad.Stav > 0)
                throw new ArgumentException("Nelze odebrat neprázdnou nádrž.");
            nadrze.Remove(nad);
        }

        public Nadrz NajitPodleIdentifikatoru(string identifikator)
        {
            return nadrze.FirstOrDefault(n => n.Identifikator == identifikator.ToLower()) ?? throw new ArgumentException("Nádrž nebyla nalezena.");
        }

        public Nadrz NajitPodlePoradi(int poradi)
        {
            if (poradi < 0 || poradi >= nadrze.Count)
                throw new ArgumentException("Pořadové číslo je mimo rozsah.");
            return nadrze[poradi];
        }

        public List<Nadrz> ZiskatSeznam() => nadrze;

        public void SeradPodleStavu(bool vzestupne)
        {
            nadrze = vzestupne ? nadrze.OrderBy(n => n.Stav).ToList() : nadrze.OrderByDescending(n => n.Stav).ToList();
        }

        public void SeradPodleIdentifikatoru(bool vzestupne)
        {
            nadrze = vzestupne ? nadrze.OrderBy(n => n.Identifikator).ToList() : nadrze.OrderByDescending(n => n.Identifikator).ToList();
        }
    }

    public partial class MainForm : Form
    {
        private SeznamNadrzi seznamNadrzi = new SeznamNadrzi();
        private ListBox listBox;
        private TextBox vyhledavaniBox;

        public MainForm()
        {
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            TextBox idBox = new TextBox() { Top = 20, Left = 20, Width = 100, PlaceholderText = "ID nádrže" };
            TextBox objemBox = new TextBox() { Top = 50, Left = 20, Width = 100, PlaceholderText = "Objem" };
            Button addButton = new Button() { Text = "Přidat nádrž", Top = 80, Left = 20 };
            Button removeButton = new Button() { Text = "Odebrat nádrž", Top = 110, Left = 20 };
            TextBox mnozstviBox = new TextBox() { Top = 150, Left = 20, Width = 100, PlaceholderText = "Množství" };
            Button pridatButton = new Button() { Text = "Přidat do nádrže", Top = 180, Left = 20 };
            Button odebratButton = new Button() { Text = "Odebrat z nádrže", Top = 210, Left = 20 };
            listBox = new ListBox() { Top = 250, Left = 20, Width = 200, Height = 200 };
            vyhledavaniBox = new TextBox() { Top = 460, Left = 20, Width = 100, PlaceholderText = "Vyhledat ID" };
            Button vyhledatButton = new Button() { Text = "Najít", Top = 490, Left = 20 };

            vyhledatButton.Click += (s, e) => VyhledatNadrz(vyhledavaniBox.Text);

            Controls.Add(idBox);
            Controls.Add(objemBox);
            Controls.Add(addButton);
            Controls.Add(removeButton);
            Controls.Add(mnozstviBox);
            Controls.Add(pridatButton);
            Controls.Add(odebratButton);
            Controls.Add(listBox);
            Controls.Add(vyhledavaniBox);
            Controls.Add(vyhledatButton);
        }

        private void VyhledatNadrz(string id)
        {
            try
            {
                var nadrz = seznamNadrzi.NajitPodleIdentifikatoru(id);
                MessageBox.Show(nadrz.ToString(), "Nádrž nalezena", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
